module.exports = {

    Developers: "871772310238019665", // ايدي تبعك

    Bot: {
        ClientID: "1248247806062231715", // ايدي البوت
        Color: "BLURPLE", // مش مهمه
    },


    comeRole: "1246402793292431411", // الي يقدر يستخدم امر come

}